import ToDoList from './ToDoList.jsx'
import './App.css'

function App() {
  return (

    <ToDoList/>
    
  )
}

export default App
