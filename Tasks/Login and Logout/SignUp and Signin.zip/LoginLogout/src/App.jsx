import React from 'react';
import './App.css';
import Home from './SigninSignup/home';
import SigninSignup from './SigninSignup/SigninSignup';

function App() {
  return (
    <div>
      <SigninSignup/>
    </div>
  );
}

export default App;
